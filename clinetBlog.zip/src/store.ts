import { createStore, applyMiddleware } from 'redux';
import { createLogger } from 'redux-logger';
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';
import { IComment } from './models/comment';
import { IGame } from './models/game';

export interface State {
    isGettingGames: boolean;
    games: IGame[];
    comments: IComment[];
}


const initialState: State = {
    isGettingGames: false,
    games: [],
    comments: [],
}

export interface Action {
    type: string;
    payload: Record<string, any>;
}

export enum Actions {
    Login = 'LOGIN',
    Register = 'REGISTER',
    SignOut = 'SIGN_OUT',
    CreateComment = 'CREATE_COMMENT',
    GetGamesPending = 'GET_GAMES_PENDING',
    GetGamesSuccess = 'GET_GAMES_SUCCESS',
    GetGamesFail = 'GET_GAMES_FAIL',
    PostGamesFail = 'POST_GAMES_FAIL',
}

const reducer = (state = initialState, action: Action) => {
    switch (action.type) {
        case Actions.Register: {
            const { msg } = action.payload;
            console.log({ msg })
            return {
                ...state,
                isLoggedIn: true,
                message: msg
            }
        }

        case Actions.GetGamesPending: {
            return {
                ...state,
                isGettingGames: true,
            }
        }

        case Actions.GetGamesFail: {
            return {
                ...state,
                isGettingGames: false,
            }
        }
        case Actions.PostGamesFail: {
            return {
                ...state,
                isGettingGames: false,
            }
        }

        case Actions.GetGamesSuccess: {
            const { categoryGames } = action.payload;
            console.log("those are the categoryGames", categoryGames)
            return {
                ...state,
                isGettingGames: false,
                games: categoryGames,
            }
        }
        case Actions.CreateComment: {
            const { comments } = state;
            const { newComment } = action.payload;
            const modifiedComments = comments.concat();
            modifiedComments.push(newComment)
            console.log("this is what i got from payload:", newComment)
            return {
                ...state,
                comments: modifiedComments,
            }
        }

        default: {
            return state;
        }
    }
}

export function createReduxStore() {
    const logger = createLogger();
    const middleware = composeWithDevTools(applyMiddleware(thunk, logger));
    return createStore(reducer, middleware);
}