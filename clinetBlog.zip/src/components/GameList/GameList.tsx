import React from 'react';
import { IGame } from '../../models/game';
import { Game } from '../Game/Game';
import { State } from '../../store';
import { connect } from 'react-redux';
import { createGetGamesAction } from '../../actions';
import { Link } from 'react-router-dom';

interface GameListProps {
    category: string;
    games: IGame[];
    getGames(category: string): void;
    isLoading: boolean;
}

class _GameList extends React.Component<GameListProps> {

    render() {
        const { isLoading, games } = this.props;
        console.log('those are the games', games)
        if (isLoading) {
            return 'Getting GAME list...';
        }

        return (
            <div >
                {games.map((game, i) =>
                    <div key={i} >
                        <div key={game.ID}>
                            <Game id={game.ID} />
                            <Link to={`/game/${game.ID}`}>TO COMMENTS</Link>
                        </div>
                    </div>
                )}
            </div>
        );
    }
    componentDidMount() {
        console.log('componentDidMount')
        const { getGames, category } = this.props;
        console.log({ category })
        getGames(category);
    }
}


const mapStateToProps = (state: State) => ({
    games: state.games,
    isLoading: state.isGettingGames,
});

const mapDispatchToProps = {
    getGames: createGetGamesAction,
}


export const GameList = connect(mapStateToProps, mapDispatchToProps)(_GameList);
