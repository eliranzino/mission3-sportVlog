import React from 'react';
import { connect } from 'react-redux';
import './Game.css';
import { Button } from 'react-bootstrap';
import { IGame } from '../../models/game';
import { State } from '../../store';

interface TodoProps {
    games: IGame[];
    id: number;
}

class _Game extends React.Component<TodoProps> {
    render() {
        const {games, id} = this.props;
        const game = games.find(g => g.ID == id);
        if (!game) {
            return null;
        }
        const { teamA, teamB, scoreA, scoreB, date, category } = game;
        return (
            <div  className="game">
                    <h4>{category} GAME!</h4>
                    <p>{teamA}</p> VS <p>{teamB}</p>
                    <p>{date}</p>
                    <p>score {teamA}: {scoreA}</p>
                    <p>score {teamB}: {scoreB}</p>
            </div>
        )
    }

}

const mapStateToProps = (state: State) => ({
    games: state.games,
});



export const Game = connect(mapStateToProps)(_Game);