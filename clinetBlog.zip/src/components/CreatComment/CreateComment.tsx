import React, { FormEvent } from 'react';
import { connect } from 'react-redux';
import { creatCommentAction } from '../../actions';
import "bootstrap/dist/css/bootstrap.min.css"
import { Button } from 'react-bootstrap';
import { State } from '../../store';


interface CreateCommentsProps {
    createComment(comment: string,  ID: number): void;
    id: number;
}

interface CreateCommentsState {
    comment: string;
}

class _CreateComments extends React.Component<CreateCommentsProps, CreateCommentsState> {
    state: CreateCommentsState = {
        comment: '',
    }
    render() {
        const { comment } = this.state;

        return (
            <div>
                <form onSubmit={this.onSubmit} >
                    <h4>Add a comment:</h4>
                    <textarea value={comment} onChange={this.handleInputChange} required name="comment"
                        placeholder="Write here your comment..."></textarea>
                    <br />
                    <Button type="submit" >SAVE</Button>
                    <br/>
                </form>
            </div>
        )
    }

    handleInputChange = (e: any) => {
        const { value, name } = e.target;
        this.setState({
            [name]: value,
        } as any);
    }

    onSubmit = (e: FormEvent) => {
        e.preventDefault();
        const { comment } = this.state;
        const { createComment, id } = this.props;
        console.log(comment);
        createComment(comment,id );
    }
}
const mapDispatchToProps = {
    createComment: creatCommentAction,
}
const mapStateToProps = (state: State) => ({
    games: state.games,
});
export const CreateComments = connect(mapStateToProps, mapDispatchToProps)(_CreateComments);