export interface IGame {
    ID: number;
    teamA: string;
    teamB: string;
    scoreA: number;
    scoreB: number;
    date: Date;
    category: string;

}