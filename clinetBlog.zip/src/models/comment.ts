export interface IComment {
    ID: number;
    comment: string;
    gameId: number;
    date: Date;
}
