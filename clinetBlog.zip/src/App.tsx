import React from 'react';
import './App.css';
import { Switch, Route, Redirect } from 'react-router-dom';
import { CreateComments } from './components/CreatComment/CreateComment';
import { GameList } from './components/GameList/GameList'
import { Game } from './components/Game/Game'


export class App extends React.Component {

  render() {
    return (
      <div className="App">
        <h3>Welcome to the Blog App!</h3>
        <Switch>
          <Route path="/Tasks">
          </Route>
          <Route path="/games/:category">
            {({ match }) => <GameList category={match?.params.category} />}
          </Route>
          <Route path="/game/:id">
            {({ match }) =>
              <div>
                <Game id={match?.params.id} />
                <CreateComments id={match?.params.id}/>
              </div>}
          </Route>
          <Route path="/">
            <Redirect to="/games/football" />
            {({ match }) => <GameList category={match?.params.category} />}
          </Route>
        </Switch>
      </div>
    );
  }
}

export default App;
