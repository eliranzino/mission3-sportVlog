import { Actions, Action } from "./store";
import { Dispatch } from "redux";
import axios from 'axios';
import { IGame } from "./models/game";
import { IComment } from "./models/comment";

const SERVER_URL = 'http://localhost:4000';

export const createGetGamesAction = (category: string) => {
    return async (dispatch: Dispatch<Action>) => {
        dispatch({
            type: Actions.GetGamesPending,
            payload: {},
        });
        try {
            const response = await axios.get<IGame[]>(`${SERVER_URL}/games/${category}`, {
            });
            const categoryGames = response.data;
            console.log('you in gettttt')
            console.log({ categoryGames })
            dispatch({
                type: Actions.GetGamesSuccess,
                payload: {
                    categoryGames,
                }
            });
        }
        catch {
            dispatch({
                type: Actions.GetGamesFail,
                payload: {},
            });
            console.log("you couldnt get the games")
        }
    }
}



export const creatCommentAction = (comment: string, ID: number) => {
    return async (dispatch: Dispatch<Action>) => {
        try {
            axios({
                method: 'post',
                url: `${SERVER_URL}/games/${ID}`,
                data: JSON.stringify(comment)

            }).then((content) => {
                console.log('this is what i get from post', content.data);
                dispatch({
                    type: Actions.CreateComment,
                    payload: {
                        newComment: content.data,
                    }
                });

            })
        }
        catch {
            dispatch({
                type: Actions.PostGamesFail,
                payload: {},
            });
        }
    }
}



