import Joi from '@hapi/joi';

export const commentSchema = Joi.object({
    id: Joi.number().required(),
    comment: Joi.string().required(),
});