import joi from "@hapi/joi";

export const gameSchema = joi.object({
  teamA: joi.string().min(1).max(500).required(),
  teamB: joi.string().min(1).max(500).required(),
  scoreA: joi.number().integer().required(),
  scoreB: joi.number().integer().required(),
  date: joi.date().required(),
  category: joi.string().min(1).max(500).required(),
});
