create database sportGames;

use sportGames;

create table games (
ID int not null auto_increment,
teamA varchar(100) not null,
teamB varchar(100) not null,
scoreA int default 0,
scoreB int default 0,
date datetime not null,
category varchar(100),
primary key (ID)
);

INSERT INTO games (teamA, teamB, scoreA, scoreB, date, category) 
VALUES ("FC Barcelona", "Real-Madrid", 3,1,"2019-06-11 12:00", "football"),
("Chelsea", "Man united",2,2,"2019-06-12 12:00", "football"),
("Maccabi Tel-Aviv","Maccabi-Haifa", 2,0,"2019-06-13 12:00", "football"),
("Maccabi Tel-Aviv", "cska Mooscow", 82,61,"2019-06-14 12:00","basketBall"),
("Maccabi Tel-Aviv", "Real-Madrid", 88,91,"2019-06-15 12:00","basketBall"),
("FC-Barcelona", "Real-Madrid", 80,81, "2019-06-16 12:00","basketBall");

create table sportGames.comments (
ID INT not null auto_increment,
comment VARCHAR(200) not null,
gameId INT NULL,
date dateTime not null default now(),
primary key (ID)
);