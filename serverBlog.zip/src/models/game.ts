export interface Game {
    ID: string;
    teamA: string;
    teamB: string;
    scoreA: number;
    scoreB: number;
    date: Date;
    category: string;
}