import express from "express";
import {  getGames, getAllGames, addComment, getComments } from '../gameQueries'
//import { gameSchema } from "../schemas/game";
import { commentSchema } from "../schemas/comment";


const router = express.Router();

router.post('/:id', async (req, res) => {
    console.log("u in post");
    const { id } = req.params;
    const { comment } = req.body;

    const result = commentSchema.validate({id, comment });
    if(result.error){
        res.status(400).send(JSON.stringify({success: false, msg: result.error}));
        return;
    }
//@ts-ignore
    const ID = await addComment(comment, id);

    const newComment = {comment, id}

    if(ID){
        res.send(newComment)
    }else{
        res.status(500).send(JSON.stringify({success: false, msg: 'Please try again later.'}))
    }
});

router.get('/:category', async (req, res) => {
    //@ts-ignore
    console.log("u in get")
    const { category } = req.params;
    console.log('the req query is:', category)
    if (!isNaN(Number(category))) {
        res.status(400).send('category must be a string');
        return;
    }
    try {
        const games = await getGames(category.toString());
        res.send(games);
    } catch (e) {
        res.status(500).send('Server is unavailable, please try again later');
    }
});

router.get('/', async (req, res) => {
    //@ts-ignore
    console.log("u in get")
    try {
        const games = await getAllGames();
        res.send(games);
    } catch (e) {
        res.status(500).send('Server is unavailable, please try again later');
    }
});

router.get('/:id/comments', async (req, res) => {
    //@ts-ignore
    console.log("u in get")
    const { id } = req.params;
    if (isNaN(Number(id))) {
        res.status(400).send('id must be a string');
        return;
    }
    try {
        const comments = await getComments(id);
        res.send(comments);
    } catch (e) {
        res.status(500).send('Server is unavailable, please try again later');
    }
});






/*
router.put('/:id/toggleComplete', async (req, res) => {
    //@ts-ignore
    const { id: userId } = req.user;
    console.log('THIS IS the userId', userId)
    const { id } = req.params;
    console.log('this is the ID', id)
    if (isNaN(Number(userId))) {
        res.status(400).send('userId must be a number');
        return;
    }

    if (isNaN(Number(id))) {
        res.status(400).send('id must be a number');
        return;
    }
    const result = await toggleComplete(Number(id), Number(userId));
    res.send(
        JSON.stringify({ success: true, msg: "Todo toggled successfully.", id })
      );
});

router.delete('/:id', async (req, res) => {
    //@ts-ignore
    const { id: userId } = req.user;
    console.log('the req user is-', userId);
    const { id } = req.params;
    if (isNaN(Number(userId))) {
        res.status(400).send('userId must be a number');
        return;
    }

    if (isNaN(Number(id))) {
        res.status(400).send('id must be a number');
        return;
    }
    const result = await deleteTodo(Number(id), Number(userId));
    res.send({result, id});
});
*/

export { router as games };