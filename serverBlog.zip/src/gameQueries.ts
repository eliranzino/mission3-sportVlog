import {sql} from './sql';
import { Game } from './models/game';


export async function addComment(comment: string, id: number): Promise<number> {
    const [{insertId}] = await sql.execute('INSERT INTO comments (comment, gameId) VALUES (?, ?)', [comment, id]);
    return insertId;
}

export async function getGames(category: string): Promise<Game[]> {
    const [games] = await sql.execute('SELECT * FROM games WHERE category = ?', [category]);
    return games;
}

export async function getComments(id: string): Promise<Game[]> {
    const [comments] = await sql.execute('SELECT * FROM comments WHERE id = ?', [id]);
    return comments;
}


export async function getAllGames(): Promise<Game[]> {
    const [games] = await sql.execute('SELECT * FROM games');
    return games;
}

export async function toggleComplete(todoId: number, userId: number): Promise<boolean> {
    const [result] = await sql.execute('UPDATE todos SET Complete = NOT Complete WHERE id = ? AND userId = ?', [todoId, userId]);
    return result.affectedRows > 0;
}

export async function deleteTodo(todoId: number, userId: number): Promise<boolean> {
    const [{affectedRows}] = await sql.execute('DELETE FROM todos WHERE id = ? AND userId = ?', [todoId, userId])
    return affectedRows > 0
}