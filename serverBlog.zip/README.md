# express-ts
A Minimal Express Typescript boilerplate

Use this template repository to create a new Node project with Express and Typescript installed

## Instructions

* Type `npm i`
* Type `npm start`
* Open your browser and go to http://localhost:4000
* WIN!
